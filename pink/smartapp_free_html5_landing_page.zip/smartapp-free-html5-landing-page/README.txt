Responsive Mobile First Web Template
------------------------------------
Author URI: http://webthemez.com/

SmartApp - HTML5 Landing Page:
SmartApp is multipurpose landing page designed to showcase your web, mobile app, new products, modules, plugins and other. It is fully responsive and looks awesome on all types of devices (desktop, notebook, tablet and mobile). This theme is built upon Bootstrap 3.3.1 framework. Clean and fast, easy to customize and use.



Features : 
-------------
Twitter Bootstrap 3.2.0
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design
One page Template
CSS Animation
Google Fonts Support
Font Awesome
Gallery Section Lightbox
Smooth Scrolling
Fully Customizable


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

**Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).

**For more details contact: author (webthemez@gmail.com)
